#include <stdio.h>
#define MAX_NUMERO 99999999
#define QTDE_NUMERAIS 10


int main(){
    int numerais[QTDE_NUMERAIS];
    int iCont, jCont;
    int maiorBase;
    int divisor;
    int numero, atual;
    int numeral;
    int maisSignificativo;
    int A, B;
    
    printf("Informe o intervalo dos numeros a serem contados :\\> ");
    scanf("%d %d", &A, &B);
    
    for(iCont = 0; iCont < QTDE_NUMERAIS; iCont++)
        numerais[iCont] = 0;    
    
    for(iCont = MAX_NUMERO, maiorBase=1; iCont >= 10; iCont/=10, maiorBase++);
    
    for(iCont = 1, divisor=1; iCont < maiorBase; iCont++, divisor*=10);


     for(numero = A; numero <= B; numero++){
        
        atual = numero;
        maisSignificativo = 0;
        
        for(iCont =  divisor; iCont >= 1; iCont/=10){
            numeral = atual / iCont;
            atual %= iCont;
            
            if(numeral > 0)
                maisSignificativo = 1;
                
            if(maisSignificativo == 1)
                numerais[numeral]++;
            
        }
    }    
    
    for(iCont = 0; iCont < QTDE_NUMERAIS; iCont++)
        printf("%d ", numerais[iCont]);      

}
