#include <stdio.h>
#define MAX_NUMERO 99999999

int main(){
    int iCont, jCont;
    int maiorBase;
    int divisor;
    int numeroACM = 719;
    int numeroDecimal = 0;
    int numero;
    int numeral;
    int fat;
    
    printf("Informe o numero em ACM :\\> ");
    scanf("%d", &numeroACM);
    
    for(iCont = MAX_NUMERO, maiorBase=1; iCont >= 10; iCont/=10, maiorBase++);
    
    for(iCont = 1, divisor=1; iCont < maiorBase; iCont++, divisor*=10);

    numero = numeroACM;
    for(iCont =  divisor; iCont >= 1; iCont/=10){
        numeral = numero / iCont;
        numero %= iCont;

        for(fat = 1, jCont = maiorBase; jCont >=1; jCont--)
            fat *= jCont;
            
        maiorBase--;    
        
        numeroDecimal += fat * numeral;    

    }

    printf("%d\n", numeroDecimal);

}
