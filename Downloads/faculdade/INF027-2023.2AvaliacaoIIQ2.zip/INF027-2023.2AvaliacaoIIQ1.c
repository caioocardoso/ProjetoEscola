#include <stdio.h>
#define MAX_TAM 512

int main(){
    
    int vetor[MAX_TAM];
    int venda;
    int sentinela;
    int iCont;
    int total;
    
    sentinela = 0;
    do{
        scanf("%d", &venda);
        if(venda > 0)
            vetor[sentinela++] = venda;    
        else if(venda == 0)
            sentinela--;
    }while(venda >= 0);    
    total=0;
    for(iCont = 0; iCont < sentinela; iCont++)
        total+= vetor[iCont];
        
    printf("Total: %d\n", total);

    return 0;
}
