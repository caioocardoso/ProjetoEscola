#include <stdio.h>
#define QTDE_EXPOENTES 8

int main(){
    
    int iCont, numero;
    int divisivel;
    int qtdeExpoentesMersene;
    int termo;
    
    qtdeExpoentesMersene = 0;
    int mersene, jCont, base;
    
    termo = 2;
    while(qtdeExpoentesMersene < QTDE_EXPOENTES){
        base = 1;
        for(jCont = 0; jCont < termo; jCont++)
            base *= 2;
        mersene = base - 1;         
        
        divisivel = 0;
        for(iCont = 1; iCont < mersene; iCont++)
            if(mersene % iCont == 0)
                divisivel++;
        if(divisivel < 2){
            printf("%d %d\n", termo, mersene);
            qtdeExpoentesMersene++;
        } 
        termo++;
    }        
}
